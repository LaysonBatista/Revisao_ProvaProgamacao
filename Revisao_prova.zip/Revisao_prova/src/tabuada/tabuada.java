/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tabuada;

import java.awt.Component;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author marce
 */
public class tabuada {

    private static Component rootPane;
    
    public static void main(String[] args) throws IOException{
        
        
        Date data = new Date();
        
        String s ="";
        
        int numero = 0;
        int i = 0;
        
        s = JOptionPane.showInputDialog(null,"Informe o numero da tabuada: ");
        numero = Integer.parseInt(s);
        
        
       FileWriter arq = new FileWriter("C:\\Users\\marce\\tabudada de " + numero +".txt");
       PrintWriter gravarArq = new PrintWriter(arq);
       
       
       gravarArq.printf("\nNome: Tabuada de " + numero);
       gravarArq.printf("\nData: " + data); 
       
       gravarArq.printf("\n+---Resultado---+");
       
       for(i=1;i<=10;i++){
        gravarArq.printf("\n| " + i + " X " + numero + " = " + (i*numero) + " |");
       }
       
       arq.close();
      
       JOptionPane.showMessageDialog(rootPane, "Tabuada de " + numero + " concluida com sucesso no caminho: C:\\Users\\marce");
        
        
    }
    
}
