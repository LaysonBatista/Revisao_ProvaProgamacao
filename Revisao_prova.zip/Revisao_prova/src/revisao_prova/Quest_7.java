/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author marce
 */
public class Quest_7 {

    private static Component rootPane;
    
    public static void main(String[] args){
        DataInputStream dado = new DataInputStream(System.in);
        
        int valor; 
        int maior = 0;
        int menor = 0; 
        int soma = 0; 
        int quantidade = 0;
        
        String s = "";
       
        
        do{
        s = JOptionPane.showInputDialog(null,"Informe algum valor: ");
        valor = Integer.parseInt(s); 
        
        if(maior == 0 || valor > maior){
            maior = valor;
        }
        if(menor == 0 || valor < menor){
            menor = valor;
        }
        
        quantidade++;
        soma += valor;
        
        } while(valor > 0 && valor != 0);
        
        if(quantidade > 0) {
            double media = soma/quantidade;
            
           JOptionPane.showMessageDialog(rootPane,
                   "Maior valor informado: " + maior + 
                   "\nMenor valor informado: " + menor + 
                   "\nQuantidade de valores informados: " + quantidade + 
                   "\nSoma dos valores informados: " + soma + 
                   "\nMédia dos valores informados: " + media);
           
           
        }
        
           
        
        
        
    
}
}