/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author marce
 */
public class Quest_6 {

    private static Component rootPane;
    
    public static void main(String[] args){
        DataInputStream dado =  new DataInputStream(System.in);
        
        String s = "";
        int num = 0;
       
        do{
        s = JOptionPane.showInputDialog(null,"Digite algum numero: ");
        num = Integer.parseInt(s);
        
        if(num > 0){
         JOptionPane.showMessageDialog(rootPane, "Positivo");   
        } else if(num < 0){
            JOptionPane.showMessageDialog(rootPane, "Negativo");
        } else {
            JOptionPane.showMessageDialog(rootPane, "Fim do laço");
        }
        
        }while(num != 0);
        
        
    
    }
}
