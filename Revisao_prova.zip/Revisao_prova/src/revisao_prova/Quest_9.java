  /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.awt.Component;
import java.io.DataInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author marce
 */
public class Quest_9 {

    private static Component rootPane;
    public static void main(String[] args){
        
         DataInputStream dado = new DataInputStream(System.in);
        String s = "";
        
        int min = 0;
        int max = 0;
        int x = 0;
        int totalx = 0;
        int quantidadeDeValores = 0;
        int quantidadeDeValoresTotal = 0;
        int quantidade = 0;
        
        
        s = JOptionPane.showInputDialog(null,"Digite o numero Min: ");
        min = Integer.parseInt(s);
        
        
        s = JOptionPane.showInputDialog(null,"Digite o numero Max: ");
        max = Integer.parseInt(s);
        
        
        if(min > max){
           List<Integer> numerosInt = new ArrayList<>();
           Integer[] numerosInteiros = new Integer[numerosInt.size()];
           JOptionPane.showMessageDialog(rootPane, "Valor Min maior que valor Max"); 
           JOptionPane.showMessageDialog(rootPane, "Invertendo...");
                 
           
           JOptionPane.showMessageDialog(rootPane, 
                   "Seu novo valor Mim: "  + max + 
                   "\nSeu novo valor Max: " + min); 

            int novoMin = max;
            int novoMax = min;
  
        do{
        s = JOptionPane.showInputDialog(null,"Digite o numero X: ");
        x = Integer.parseInt(s); 
 
        if(x > novoMin && x < novoMax){
            totalx++;
            numerosInt.add(x);
            numerosInt.toArray(numerosInteiros);
            quantidade++;
            
        }
        
        else if(x==0){
            JOptionPane.showMessageDialog(rootPane, "Fim do laço");
        } else {    
         JOptionPane.showMessageDialog(rootPane, "Valor fora do intervalo [Min, Max] ignorado na totalização");
         quantidadeDeValores++;
        }
          
        } while(x != 0);
        
        quantidadeDeValoresTotal = totalx + quantidadeDeValores;

        JOptionPane.showMessageDialog(rootPane, "Total: " + totalx);
        JOptionPane.showMessageDialog(rootPane, "Quantidae: " + quantidadeDeValoresTotal);
        
        
        JOptionPane.showMessageDialog(rootPane, "Valores no vetor: " + numerosInt);
        //JOptionPane.showMessageDialog(rootPane, "Valores no vetor: " + (Arrays.toString(numerosInteiros)));
               

        } else {
            
         List<Integer> numerosInt = new ArrayList<>();
         Integer[] numerosInteiros = new Integer[numerosInt.size()];
        
        do{
           
            
        s = JOptionPane.showInputDialog(null,"Digite o numero X: ");
        x = Integer.parseInt(s); 
 
        if(x > min && x < max){
            totalx++;
            numerosInt.add(x);
            numerosInt.toArray(numerosInteiros);
            quantidade++;
            
        }
        else if(x==0){
            JOptionPane.showMessageDialog(rootPane, "Fim do laço");
        } else {    
         JOptionPane.showMessageDialog(rootPane, "Valor fora do intervalo [Min, Max] ignorado na totalização");
         quantidadeDeValores++;
        }
          
        } while(x != 0);
        
        quantidadeDeValoresTotal = totalx + quantidadeDeValores;
        
        JOptionPane.showMessageDialog(rootPane, "Total: " + totalx);
        JOptionPane.showMessageDialog(rootPane, "Quantidae: " + quantidadeDeValoresTotal);
        
        JOptionPane.showMessageDialog(rootPane, "Valores no vetor: " + numerosInt);
    }
    
}
        
        
}
