/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.awt.Component;
import java.io.DataInputStream;
import javax.swing.JOptionPane;

/**
 *
 * @author marce
 */
public class Quest_3 {

    private static Component rootPane;
     public static void main(String[] args){
        
        DataInputStream dado;
        String s = "";
        
        int primeiroNumero = 0;
        int segundoNumero = 0;

        s = JOptionPane.showInputDialog(null,"Digite o primeiro número: ");
        dado = new DataInputStream(System.in);
        primeiroNumero = Integer.parseInt(s);
        
        s = JOptionPane.showInputDialog(null,"Digite o segundo número: ");
        dado = new DataInputStream(System.in);
        segundoNumero = Integer.parseInt(s);
       
        int soma = primeiroNumero + segundoNumero;
        
        if(primeiroNumero >0 && segundoNumero >0 || primeiroNumero <0 && segundoNumero <0){
        JOptionPane.showMessageDialog(rootPane, "Soma de " + primeiroNumero + " com " + segundoNumero + " = " + soma);
        } else {
           JOptionPane.showMessageDialog(rootPane, "Dados de Entrada são Inválidos");
        }
        
  }
}
