/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package revisao_prova;

import java.util.Scanner;

/**
 *
 * @author marce
 */
public class Quest_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite o primeiro número:");
        int primeiroNumero = scanner.nextInt();
        
        System.out.println("Digite o segundo número:");
        int segundoNumero = scanner.nextInt();
        
        int soma = primeiroNumero + segundoNumero;
        
       
        System.out.println("Soma de " + primeiroNumero + " com " + segundoNumero + " = " + soma);
        
        
        
         
    }
    
}
