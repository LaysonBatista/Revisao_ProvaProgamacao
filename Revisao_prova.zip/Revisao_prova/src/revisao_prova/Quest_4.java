/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.util.Scanner;

/**
 *
 * @author marce
 */
public class Quest_4 {
    
    public static void main(String[] args){
    Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite o valor do primeiro lado do triangulo: ");
        double lado1 = scanner.nextDouble();
        
        System.out.println("Digite o valor do segundo lado do triangulo: ");
        double lado2 = scanner.nextDouble();
        
        System.out.println("Digite o valor do terceiro lado do triangulo: ");
        double lado3 = scanner.nextDouble();
        
        if(lado1 <=0 || lado2 <=0 || lado3 <= 0){
            System.out.println("O Valor digitado e invalido");
        }
        else if(lado1 + lado2 > lado3 && lado1 + lado3 > lado2 && lado2 + lado3 > lado1){
            if(lado1 == lado2 && lado1 == lado3){
                System.out.println("Triangulo equilatero");
            } else if (lado1 == lado2 || lado1 == lado3 || lado2 == lado3){
                System.out.println("Triagulo isosceles");
            } else {
                System.out.println("escaleno");
            }
        } else {
            System.out.println("Os valores nao formam um trinagulo");
        }
        scanner.close();
        
    }
    
  
}
