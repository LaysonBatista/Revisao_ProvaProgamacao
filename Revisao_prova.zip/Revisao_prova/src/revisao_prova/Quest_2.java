/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.util.Scanner;

/**
 *
 * @author marce
 */
public class Quest_2 {
    
     public static void main(String[] args){
    
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite o primeiro numero:");
        int primeiroNumero = scanner.nextInt();
        
        System.out.println("Digite o segundo numero:");
        int segundoNumero = scanner.nextInt();
        
        int soma = primeiroNumero + segundoNumero;
        
        if(primeiroNumero >0 && segundoNumero >0){
        System.out.println("Soma de " + primeiroNumero + " com " + segundoNumero + " = " + soma);
        } else {
            System.out.println("Dados de Entra sao invalido");
        }
  }
}
     
