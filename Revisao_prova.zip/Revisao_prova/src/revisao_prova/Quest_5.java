/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao_prova;

import java.awt.Component;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;


/**
 *
 * @author marce
 */
public class Quest_5 {

    private static Component rootPane;
    
    public static void main (String[] args) throws IOException{
        DataInputStream dado = new DataInputStream(System.in);
        
        FileWriter arq = new FileWriter("C:\\Users\\marce\\lutador.txt");
        PrintWriter gravarArq = new PrintWriter(arq);
        
        String s ="";
        
        String nomeLutador = null;
        float pesoLutador = 0;
        
        s = JOptionPane.showInputDialog(null,"informe o nome do lutador: ");
        nomeLutador = String.valueOf(s);
        s = JOptionPane.showInputDialog(null, "Informe o peso do lutador: ");
        pesoLutador = Float.parseFloat(s);
   
       
        JOptionPane.showMessageDialog(rootPane, "Nome fornecido: " + nomeLutador 
                + "\nPeso fornecido: " + pesoLutador);
        
        
        
        if(pesoLutador < 65){
            JOptionPane.showMessageDialog(null,"Categoria: Pena");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Pena");
        } else if(pesoLutador >= 65 && pesoLutador < 72){
            JOptionPane.showMessageDialog(null,"Categoria: Leve");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Leve");
        } else if(pesoLutador >= 72 && pesoLutador < 79){
            JOptionPane.showMessageDialog(null, "Categoria: Ligeiro");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Ligeiro");
        } else if(pesoLutador >= 79 && pesoLutador < 86){
            JOptionPane.showMessageDialog(null,"Categoria: Meio Medio");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Meio Medio");
        } else if(pesoLutador >= 86 && pesoLutador < 93){
            JOptionPane.showMessageDialog(null,"Categoria: Medio");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Medio");
        } else if(pesoLutador >= 93 && pesoLutador < 100){
            JOptionPane.showMessageDialog(null,"Categoria: Meio Pesado");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Meio Pesado");
        } else if(pesoLutador >= 100){
            JOptionPane.showMessageDialog(null, "Categoria: Pesado");
            gravarArq.printf("O lutador "+ nomeLutador + " pesa " + pesoLutador + " kg e se enquadra na categoria " + "Pesado");
        }
        
        
       arq.close();
    }
    
}
